/*Function to*/
function runme(){
	document.getElementById("landingPage").style.display = "none";
	document.getElementById("real").style.display="block";
	player = document.getElementById("player");
  	player.play();	
  	
}

function startgame(){
	player.pause()
	document.getElementById("real").style.display = "none";
	document.getElementById("game").style.display="block";
	gametime = document.getElementById("gametime");
  	gametime.play();	
}

let main = document.getElementById('landingPage');
